class CancelProcess(Exception):
    """
    Cancel Process
    """

# d3vilbot
