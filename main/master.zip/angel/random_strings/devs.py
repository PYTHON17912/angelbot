DEVLIST = [
    "5169603818",
]


HARMFUL = [
    "SESSION",
    "HEROKU_API_KEY",
    "base64",
    "bash",
    "get_me()",
    "phone",
    "os.system",
    "sys.stdout",
    "sys.stderr",
    "subprocess",
    "D3VILBOT_SESSION",
    "session.save()",
]
