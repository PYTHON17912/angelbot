from .devs import *
from .fun_str import *
from .meme_str import *
from .quotes import *
from .rands import *
