<h1 align="center">
  <b>ᏖᏂᏋ D3ᏉᎥᏝᏰᎧᏖ</b>
</h1>

<p align="center">
  <img src="https://telegra.ph/file/883f837877a4804827cac.jpg" alt=D3KRISH">
</p>

<div align="center"><img src="https://github-profile-trophy.vercel.app/?username=D3KRISH&theme=dracula&count_private=true"></div>

---

[![Python](https://img.shields.io/badge/Python-v3.9-blue)](https://www.python.org/)
![Branch](https://img.shields.io/badge/Branch-Master-orange)
![Maintenance](https://img.shields.io/badge/Maintained%3F-yes-green?&style=flat-square)
![Repo Size](https://img.shields.io/github/repo-size/TEAM-D3VIL/D3vilBot?&style=flat-square&logo=github)
<p align='middle'>
    <code><a href="https://git-scm.com/" target="_blank"> <img width="20%"   src="https://www.vectorlogo.zone/logos/git-scm/git-scm-ar21.svg"> </a></code>
    <code><a href="https://www.python.org/" target="_blank"> <img width="20%"   src="https://www.vectorlogo.zone/logos/python/python-ar21.svg"> </a></code>
    <code><a href="https://heroku.com/" target="_blank"> <img width="20%"   src="https://www.vectorlogo.zone/logos/heroku/heroku-ar21.svg"> </a></code>
    <br />
    <code><a href="https://www.mysql.com/" target="_blank"> <img width="20%"  src="https://www.vectorlogo.zone/logos/mysql/mysql-ar21.svg"> </a></code>
    <code><a href="https://redis.io/" target="_blank"> <img width="20%"  src="https://www.vectorlogo.zone/logos/redis/redis-ar21.svg"> </a></code>
    <code><a href="https://firebase.google.com/" target="_blank"> <img width="20%"  src="https://www.vectorlogo.zone/logos/firebase/firebase-ar21.svg"> </a></code>
    <br />
    <code><a href="https://www.mongodb.com/" target="_blank"> <img width="20%"  src="https://www.vectorlogo.zone/logos/mongodb/mongodb-ar21.svg"> </a></code>
    <code><a href="https://github.com/" target="_blank"> <img width="20%"  src="https://www.vectorlogo.zone/logos/github/github-ar21.svg"> </a></code>
    <code><a href="https://gitlab.com/" target="_blank"> <img width="20%"  src="https://www.vectorlogo.zone/logos/gitlab/gitlab-ar21.svg"> </a></code>
    <br />
    <code><a href="https://www.postgresql.org/" target="_blank"> <img width="20%"  src="https://www.vectorlogo.zone/logos/postgresql/postgresql-ar21.svg"> </a></code>
    <code><a href="https://telegram.org/" target="_blank"> <img width="20%"  src="https://www.vectorlogo.zone/logos/telegram/telegram-ar21.svg"> </a></code>
    <br>
      </p>  

<p align='middle'><img src='https://github-readme-streak-stats.herokuapp.com/?user=D3KRISH&theme=midnight-purple&show_icon=true' width='500"'></p> 

---

## 𝐓𝐞𝐥𝐞𝐠𝐫𝐚𝐦 🚀
- [![𝚃𝚎𝚕𝚎𝚐𝚛𝚊𝚖 𝙶𝚛𝚘𝚞𝚙](https://img.shields.io/badge/Telegram-Group-brightgreen)](https://t.me/D3VIL_BOT_SUPPORT)
- [![𝚃𝚎𝚕𝚎𝚐𝚛𝚊𝚖 𝙲𝚑𝚊𝚗𝚗𝚎𝚕](https://img.shields.io/badge/Telegram-Channel-brightgreen)](https://t.me/D3VIL_SUPPORT)
- [![BOT OWNER](https://img.shields.io/badge/CONTACT-OWNER-brightgreen)](https://t.me/D3_krish)
 
## DEPLOY FROM TELEGRAM BOT
- [![Deploy Bot From Telegram](https://img.shields.io/badge/DeployFROMTelegram-Bot-brightred)](https://telegram.dog/XTZ_HerokuBot?start=VEVBTS1EM1ZJTC9EM3ZpbEJvdCBtYXN0ZXI)

```

👆👆IF Heroku is not giving access to deploy userbot 
then you use this bot to deploy our userbot👆

```
# Tutorial 
- Full Tutorial - [![Full Tutorial](https://img.shields.io/badge/Watch%20Now-red)](https://youtu.be/PHJ3O34Pvc0)


## 🚀 𝐃𝐞𝐩𝐥𝐨𝐲 𝐓𝐨 𝐇𝐞𝐫𝐨𝐤𝐮 
- 𝙶𝚎𝚝 𝙰𝚕𝚕 𝚃𝚑𝚎 𝙽𝚎𝚌𝚎𝚜𝚜𝚊𝚛𝚢 𝚅𝚊𝚛𝚒𝚊𝚋𝚕𝚎𝚜 𝙰𝚗𝚍 𝙳𝚎𝚙𝚕𝚘𝚢 𝚃𝚘 𝙷𝚎𝚛𝚘𝚔𝚞.
- [![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/TEAM-D3VIL/D3vilBot)

 <p align="center"><a href="https://heroku.com/deploy?template=https://github.com/TEAM-D3VIL/D3vilBot"> <img src="https://img.shields.io/badge/D3VILBOT Deploy%20To%20Heroku-purple?style=for-the-badge&logo=heroku" width="220" height="38.45"/></a></p>
----
### 𝐃3𝐕𝐈𝐋𝐁𝐎𝐓_𝐒𝐄𝐒𝐒𝐈𝐎𝐍

- 𝙾𝚙𝚎𝚗 𝚁𝚎𝚙𝚕 𝙻𝚒𝚗𝚔.
- 𝚈𝚘𝚞𝚛𝚢 D3𝚟𝚒𝚕𝙱𝚘𝚝 𝚂𝚎𝚜𝚜𝚒𝚘𝚗 𝚆𝚒𝚕𝚕 𝚋𝚎 𝚜𝚊𝚟𝚎𝚍 𝚒𝚗 𝚢𝚘𝚞𝚛 𝚃𝚎𝚕𝚎𝚐𝚛𝚊𝚖 𝚂𝚊𝚟𝚎𝚍 𝙼𝚎𝚜𝚜𝚊𝚐𝚎.

- [![REPL](https://repl.it/badge/github/D3KRISH/D3vilUserbot)](https://replit.com/@D3krish/D3VILBOTSTRINGSESSION#main.py)

`bash start.sh`

## • 𝐓𝐄𝐑𝐌𝐈𝐍𝐀𝐋 •
- 𝙾𝚙𝚎𝚗 𝚝𝚑𝚎 𝚝𝚎𝚛𝚖𝚒𝚗𝚊𝚕.$ 𝙿𝚊𝚜𝚝𝚎 𝚝𝚑𝚒𝚜 𝚌𝚘𝚍𝚎 👇.

`pkg install python wget -y && pip install telethon && wget https://raw.githubusercontent.com/D3KRISH/D3vilUserbot/master/d3vil_string.py && python3 d3vil_string.py`
- Your D3vilBot Session Will be saved in your Telegram Saved Message.

----

<details>
<summary> 𝐃𝐄𝐏𝐋𝐎𝐘 𝐋𝐎𝐂𝐀𝐋𝐋𝐘•</summary>

## 𝐃𝐞𝐩𝐥𝐨𝐲 𝐋𝐨𝐜𝐚𝐥𝐥𝐲

- 𝙲𝚕𝚘𝚗𝚎 𝚝𝚑𝚎 𝚛𝚎𝚙𝚘. 

`git clone https://github.com/D3KRISH/D3vilUserbot.git`
- 𝙾𝚙𝚎𝚗 𝙲𝚕𝚘𝚗𝚎𝚍 𝙵𝚘𝚕𝚍𝚎𝚛.

`cd D3vilUserbot`
- 𝙲𝚛𝚎𝚊𝚝𝚎 VirtualEnv.

`virtualenv -p /usr/bin/python3 venv`

`. ./venv/bin/activate`
- 𝙸𝚗𝚜𝚝𝚊𝚕𝚕 𝚁𝚎𝚚𝚞𝚒𝚛𝚎𝚖𝚎𝚗𝚝𝚜.

`pip install -U -r requirements.txt`
- 𝙶𝚎𝚗𝚎𝚛𝚊𝚝𝚎 D3𝚅𝙸𝙻𝙱𝙾𝚃 𝚂𝙴𝚂𝚂𝙸𝙾𝙽.

`python d3vil_string.py`
- 𝙲𝚛𝚎𝚊𝚝𝚎 config.py 𝚘𝚛 𝚛𝚎𝚗𝚊𝚖𝚎 ex_config.py 𝚝𝚘 config.py. 𝙵𝚒𝚕𝚕 𝙰𝚕𝚕 𝚃𝚑𝚎 𝚁𝚎𝚚𝚞𝚒𝚛𝚎𝚍 𝚅𝚊𝚛𝚒𝚊𝚋𝚕𝚎𝚜.
- 𝙵𝚒𝚗𝚊𝚕𝚕𝚢 𝚂𝚝𝚊𝚛𝚝 D3𝚅𝙸𝙻𝙱𝙾𝚃 𝙱𝚢
</details>
<details>
<summary>• 𝐕𝐀𝐑𝐈𝐀𝐁𝐋𝐄 •</summary>

- `APP_ID`  =  𝙶𝚎𝚝 𝚝𝚑𝚒𝚜 𝚟𝚊𝚕𝚞𝚎 𝚏𝚛𝚘𝚖 my.telegram.𝚘𝚛𝚐 𝚘𝚛 [telegram.org bot](https://t.me/api_id_scrapperbot)
- `API_HASH`  =  𝙶𝚎𝚝 𝚝𝚑𝚒𝚜 𝚟𝚊𝚕𝚞𝚎 𝚏𝚛𝚘𝚖 my.telegram.𝚘𝚛𝚐 𝚘𝚛 [telegram.org bot](https://t.me/api_id_scrapperbot)
- `D3VILLBOT_SESSION`  =  𝙶𝚎𝚝 𝚝𝚑𝚒𝚜 𝚋𝚢 𝚞𝚜𝚒𝚗𝚐 [Repl.it](#D3VILBOT_SESSION) or from [terminal](#Terminal)
- `LOGGER_ID`  =  𝙼𝚊𝚔𝚎 𝙰 𝙲𝚑𝚊𝚗𝚗𝚎𝚕 𝙰𝚗𝚍 𝙶𝚎𝚝 𝚒𝚝'𝚜 𝙸𝙳.
- `BOT_TOKEN`  =  𝙼𝚊𝚔𝚎 𝙰 𝙱𝚘𝚝 𝙵𝚛𝚘𝚖 [@BotFather](https://t.me/botfather) 𝚊𝚗𝚍 𝚙𝚊𝚜𝚝𝚎 𝚒𝚝'𝚜 𝚝𝚘𝚔𝚎𝚗.
- `BOT_USERNAME`  =  𝙶𝚎𝚝 𝚝𝚑𝚎 𝚞𝚜𝚎𝚛𝚗𝚊𝚖𝚎 𝚘𝚏 𝚝𝚑𝚊𝚝 𝙱𝚘𝚝 𝚖𝚊𝚍𝚎 𝚏𝚛𝚘𝚖 [@Botfather](https://t.me/botfather)
</details>

<details>
<summary>⚠️ 𝐃𝐈𝐒𝐂𝐋𝐀𝐈𝐌𝐄𝐑 •</summary>
- ⚠️ 𝚆𝚎 𝚠𝚘𝚗'𝚝 𝚋𝚎 𝚛𝚎𝚜𝚙𝚘𝚗𝚜𝚒𝚋𝚕𝚎 𝚏𝚘𝚛 𝚊𝚗𝚢 𝚔𝚒𝚗𝚍 𝚘𝚏 𝚋𝚊𝚗 𝚍𝚞𝚎 𝚝𝚘 𝚝𝚑𝚒𝚜 𝚋𝚘𝚝.
- 𝙳3𝚅𝙸𝙻𝙱𝚘𝚝 was 𝚖𝚊𝚍𝚎 𝚏𝚘𝚛 𝚏𝚞𝚗 𝚙𝚞𝚛𝚙𝚘𝚜𝚎 𝚊𝚗𝚍 𝚝𝚘 𝚖𝚊𝚔𝚎 group 𝚖𝚊𝚗𝚊𝚐𝚎𝚖𝚎𝚗𝚝 𝚎𝚊𝚜𝚒𝚎𝚛.
- 𝙸𝚝'𝚜 𝚢𝚘𝚞𝚛 𝚌𝚘𝚗𝚌𝚎𝚛𝚗 𝚒𝚏 𝚢𝚘𝚞 𝚜𝚙𝚊𝚖 𝚊𝚗𝚍 𝚐𝚎𝚝𝚜 𝚢𝚘𝚞𝚛 𝚊𝚌𝚌𝚘𝚞𝚗𝚝 𝚋𝚊𝚗𝚗𝚎𝚍.
- 𝙰𝚕𝚜𝚘, 𝙵𝚘𝚛𝚔𝚜 𝚠𝚘𝚗'𝚝 𝚋𝚎 entertained.
- 𝙸𝚏 𝚢𝚘𝚞 𝚏𝚘𝚛𝚔 this 𝚛𝚎𝚙𝚘 𝚊𝚗𝚍 𝚎𝚍𝚒𝚝 plugins, 𝚒𝚝'𝚜 𝚢𝚘𝚞𝚛 𝚌𝚘𝚗𝚌𝚎𝚛𝚗 𝚏𝚘𝚛 𝚏𝚞𝚛𝚝𝚑𝚎𝚛 𝚞𝚙𝚍𝚊𝚝𝚎𝚜.
- 𝙵𝚘𝚛𝚔𝚒𝚗𝚐 𝚁𝚎𝚙𝚘 𝚒𝚜 𝚏𝚒𝚗𝚎. 𝙱𝚞𝚝 𝚒𝚏 𝚢𝚘𝚞 𝚎𝚍𝚒𝚝 𝚜𝚘𝚖𝚎𝚝𝚑𝚒𝚗𝚐 𝚠𝚎 𝚠𝚒𝚕𝚕 𝚗𝚘𝚝 𝚙𝚛𝚘𝚟𝚒𝚍𝚎 𝚊𝚗𝚢 𝚑𝚎𝚕𝚙.
- 𝙸𝚗 𝚜𝚑𝚘𝚛𝚝, 𝙵𝚘𝚛𝚔 𝙰𝚝 𝚈𝚘𝚞𝚛 𝙾𝚠𝚗 𝚁𝚒𝚜𝚔.
</details>
<p align="center">
<details> 
<summary>• 𝐂𝐑𝐄𝐃𝐈𝐓'𝐒 •</summary>
</p>


-   ⚜️[Lonami](https://github.com/Lonami) for [Telethon](https://github.com/LonamiWebs/Telethon)
-   ⚜️[HellBot](https://github.com/The-HellBot/HellBot)
-   ⚜️[Himanshu](https://t.me/H1M4N5HU0P)
-   ⚜️[Shincahn](https://t.me/Shinchan7222)
-   ⚜️[Team D3vil](https://t.me/D3VIL_OP_BOLTE)

</details>

<details> 
<summary>• 𝐋𝐈𝐂𝐄𝐍𝐂𝐄•</summary>

![](https://www.gnu.org/graphics/gplv3-or-later.png)

<h4 align="center">Copyright (C) 2021 <a href="https://github.com/TEAM-D3VIL">D3VILBOT</a></h4>

Project [D3vilBot](https://github.com/TEAM-D3VIL/D3vilBot) is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program. If not, see <https://www.gnu.org/licenses/>.
</details>
